// script.js
let score = 0;
let highScore = localStorage.getItem("highScore") || 0;
let timeLeft = 30;
let interval;
let currentAnswer;

document.getElementById("highScore").innerText = highScore;

// Start a new question
function newQuestion() {
    const num1 = Math.floor(Math.random() * 12) + 1;
    const num2 = Math.floor(Math.random() * 12) + 1;
    currentAnswer = num1 * num2;
    document.getElementById("question-text").innerText = `What is ${num1} x ${num2}?`;
    document.getElementById("answer").value = "";
}

// Check if the answer is correct
function checkAnswer() {
    const userAnswer = parseInt(document.getElementById("answer").value);
    if (userAnswer === currentAnswer) {
        score += 10;
        document.getElementById("score").innerText = score;
        document.getElementById("result").innerText = "Correct!";
        setTimeout(() => {
            document.getElementById("result").innerText = "";
        }, 1000);
        newQuestion();
    } else {
        document.getElementById("result").innerText = "Try Again!";
    }
}

// Timer countdown
function startTimer() {
    interval = setInterval(() => {
        timeLeft--;
        document.getElementById("timer").innerText = timeLeft;
        if (timeLeft <= 0) {
            clearInterval(interval);
            endGame();
        }
    }, 1000);
}

// End the game
function endGame() {
    document.getElementById("result").innerText = "Time's up!";
    if (score > highScore) {
        highScore = score;
        localStorage.setItem("highScore", highScore);
        document.getElementById("highScore").innerText = highScore;
    }
    score = 0;
    timeLeft = 30;
    document.getElementById("score").innerText = score;
    setTimeout(() => {
        document.getElementById("result").innerText = "";
        startGame();
    }, 2000);
}

// Start the game
function startGame() {
    newQuestion();
    startTimer();
}

// Initialize game on load
window.onload = startGame;
