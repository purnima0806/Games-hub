// script.js
const sentences = [
    "The quick brown fox jumps over the lazy dog.",
    "JavaScript is a versatile programming language.",
    "Coding challenges improve problem-solving skills.",
    "Practice typing to increase your speed.",
    "HTML, CSS, and JavaScript make up the web.",
    "hi idk what to do."
];

let startTime;
let typedCharacters = 0;
let currentSentence = '';
let timerInterval;

function startGame() {
    // Reset values
    document.getElementById("input").value = '';
    document.getElementById("wpm").innerText = 0;
    document.getElementById("accuracy").innerText = 0;
    document.getElementById("time").innerText = 0;
    typedCharacters = 0;

    // Get random sentence
    currentSentence = sentences[Math.floor(Math.random() * sentences.length)];
    document.getElementById("sentence").innerText = currentSentence;

    // Start timer
    startTime = new Date().getTime();
    clearInterval(timerInterval);
    timerInterval = setInterval(updateTimer, 1000);
}

function updateTimer() {
    const timeElapsed = Math.floor((new Date().getTime() - startTime) / 1000);
    document.getElementById("time").innerText = timeElapsed;
}

function checkTyping() {
    const inputText = document.getElementById("input").value;
    typedCharacters = inputText.length;

    // Calculate words per minute (WPM)
    const timeElapsed = (new Date().getTime() - startTime) / 1000 / 60; // minutes
    const wordsTyped = typedCharacters / 5;
    const wpm = Math.round(wordsTyped / timeElapsed);
    document.getElementById("wpm").innerText = wpm || 0;

    // Calculate accuracy
    let correctCharacters = 0;
    for (let i = 0; i < inputText.length; i++) {
        if (inputText[i] === currentSentence[i]) {
            correctCharacters++;
        }
    }
    const accuracy = Math.round((correctCharacters / currentSentence.length) * 100);
    document.getElementById("accuracy").innerText = accuracy || 0;

    // End game when the sentence is complete
    if (inputText === currentSentence) {
        clearInterval(timerInterval);
        document.getElementById("result").innerText = "Test complete!";
    }
}
